package com.example.demo;

public class NameNotFoundException extends Exception{
	public NameNotFoundException(String s) {
		super(s);
	}

}
