package com.example;

import static org.junit.Assert.*;

import org.junit.Test;

public class AgeValid {

	@Test
	public void test() {
		/*if the expected output==actual output- pass
		 * if the expected output!=actual output-fail-bugs
		 *  */
		AgeValidator agevalid=new AgeValidator();
		assertEquals("right to vote",agevalid.Agevalid(20));
	}

	

}
