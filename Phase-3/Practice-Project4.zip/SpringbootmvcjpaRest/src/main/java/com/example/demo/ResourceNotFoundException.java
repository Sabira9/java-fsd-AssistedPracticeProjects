package com.example.demo;

public class ResourceNotFoundException extends Exception{
	public ResourceNotFoundException(String s) {
		super(s);
	}

}
