package com.example.demo;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
public class ErrorDetails {
	private Date timestamp;
	private String errormsg;
	private String path;

}
