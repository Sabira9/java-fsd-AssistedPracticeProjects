package exception;

public class ExceptionEx {

	public static void main(String[] args) {
	try
	{
		try {
	
		int a=50/0;
		}
		catch(Exception e)
		{
		System.out.println(e);
		}
		int s[]= {1,2,3};
		s[4]=24;
	}
		catch(Exception e)
	{
			System.out.println(e);
	}
	finally
	{
		System.out.println("end");
	}
	}
}
		

