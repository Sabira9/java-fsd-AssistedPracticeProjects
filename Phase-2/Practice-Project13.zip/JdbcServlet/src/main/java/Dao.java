import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Dao {
	public int insert(Student s) throws SQLException, ClassNotFoundException
	{
	Connection con=DbUtil.getcon();
	if(con!=null)
	{
		System.out.println("Connection is estabilished");
	}
	else
	{
		System.out.println("Connection is not estabilished");
	}
	//Statement st=con.createStatement();
	String sql="insert into student values(?,?,?)";
	//int row=st.executeUpdate(sql);
	PreparedStatement ps=con.prepareStatement(sql);
	ps.setInt(1, s.getSid());
	ps.setString(2, s.getSname());
	ps.setString(3, s.getSemail());
	int row=ps.executeUpdate();
	return row;
	} 
	public ResultSet retrieval() throws SQLException, ClassNotFoundException
	{
		Connection con=DbUtil.getcon();
		if(con!=null)
		{
			System.out.println("Connection is estabilished");
		}
		else
		{
			System.out.println("Connection is not estabilished");
		}
		Statement st=con.createStatement();
		String sql="select * from student";
		ResultSet rs=st.executeQuery(sql);
		return rs;
	}

}
