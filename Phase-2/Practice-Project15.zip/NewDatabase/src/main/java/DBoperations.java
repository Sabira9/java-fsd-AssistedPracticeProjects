

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DBoperations
 */
@WebServlet("/DBoperations")
public class DBoperations extends HttpServlet {
	private static final long serialVersionUID = 1L;
       Connection con;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DBoperations() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			PrintWriter pw=response.getWriter();
		 con=DbUtil.getcon();
		 if(con!=null)
		 {
			 pw.println("Connection estabilished");
		 }
		 else
		 {
			 pw.print("Connection not estabilished");
		 }
		 response.setContentType("text/html");
		 pw.print("<html><body>");
		 Statement st=con.createStatement();
		 String sql="create database mydatabase1";
		 st.executeUpdate(sql);
		 pw.print("Created Database:mydatabase1 <br>");	
		 String sql1="use mydatabase1";
		 st.executeUpdate(sql1);
		 pw.print("Selected Database:mydatabase1 <br>");	
		 String sql2="drop database mydatabase1";
		 st.executeUpdate(sql2);
		 pw.print("Dropped Database:mydatabase1 <br>");
		 pw.print("</body></html>");
		 
		}
		catch (ClassNotFoundException e) {
            e.printStackTrace();
        } 
		catch (SQLException e) 
		{
            e.printStackTrace();
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
