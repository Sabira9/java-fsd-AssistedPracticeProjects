package methodImplement;

public class VolumeArea {
		int l,b,h;
		//Method with return type and arguments
		int calc(int a,int b,int c) {
			int vol=a*b*c;
			return vol;
		}
		//Method without return type and with arguments
	    void calc1(int a,int b,int c) {
			int vol=a*b*c;
			System.out.println("volume of box=" +vol);
		}
	  //Method with return type and no arguments
	    int calc2()
	    {
	    	int a=10,b=10,c=20;
	    	return(a*b*c);
	   
	    }
	  //Method without return type and arguments
	    void calc3()
	    {
	    	int a=10,b=10,c=20;
	    	System.out.println("volume of box="+(a*b*c)+"\n");
	    }
	    //Method overloading
	    int area(int l,int b)
	    {
	        int areaR=l*b;
	        return areaR;
	    }
	    double area(int r)
	    {
	        double areaC=3.14*r*r;
	        return areaC;
	    }
	    }



