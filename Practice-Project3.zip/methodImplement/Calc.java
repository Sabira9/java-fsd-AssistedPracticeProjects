

package methodImplement;

public class Calc {
	public static void main(String[] args) {
		VolumeArea v=new VolumeArea();
		//Call by value
		int vol=v.calc(10,10,20);
		System.out.println("With returntype and arguments");
		System.out.println("volume of box="+vol);
		System.out.println("Without returntype and with arguments");
		//call by value
		v.calc1(2,2,5);
		System.out.println("With returntype and no arguments");
		int vol1=v.calc2();
		System.out.println("volume of box="+vol1);
		System.out.println("Without returntype and arguments");
		v.calc3();
		System.out.println("Method Overloading\n");
		System.out.println("Area of Rectangle="+v.area(5,5));
		System.out.println("Area of Circle="+v.area(5));
	}

}


