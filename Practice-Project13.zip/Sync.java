package threadprac;
class ThreadRunnable  implements Runnable
{
	public void run()
	{
		runOdd();
		runEven();
	}
      synchronized public void runOdd()
	{
		for(int i=1;i<10;i+=2)
		{
			System.out.println(i);
		}
	}
      synchronized public void runEven()
     	{
     		for(int i=2;i<10;i+=2)
     		{
     			System.out.println(i);
     		}
     	}
}

public class Sync  {

	public static void main(String[] args) {
		ThreadRunnable th=new ThreadRunnable(); 
		Thread th1=new Thread(th); 
		Thread th2=new Thread(th);
		th1.start();
		th2.start();
	}

}

