package fileassisted;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
public class FileUpdate {

		public static void main(String[] args) throws IOException  {
	     FileOutputStream file=new FileOutputStream("input",true);
	     if(file!=null)
	     {
	    	 System.out.println("file is created and opened in write mode");
	     }
	     Scanner sc=new Scanner(System.in);
	     System.out.println("enter the content:");
	     String filecont=sc.nextLine();
	     byte b[]=filecont.getBytes();
	     file.write(b);
	     System.out.println("write is completed");
	     file.close();
		}
		
	}
	     


