package fileassisted;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
 class Delete {

	public void deletefile()  throws IOException {
		Scanner sc=new Scanner(System.in);
		String path="C:\\Users\\SABIRA NAZAR\\Documents\\New files\\";
		System.out.println("Enter the filename to be deleted:");
		String filename=sc.next();
		String newpath=path+filename;
		File f=new File(newpath);
		boolean b=f.delete();
		if(b!=true)
		{
			System.out.println("file not found");
		}
		else
		{
			System.out.println("file deleted");
		}
	}

}

public class FileDelete {

	public static void main(String[] args) throws IOException {
	Delete del=new Delete();
	del.deletefile();

	}

}
