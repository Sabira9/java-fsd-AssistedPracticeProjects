package arrayprac;

import java.util.Scanner;

public class MatrixMultipli {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		 System.out.println("Multiplication");
	        System.out.println("Enter the no of rows for frst matrix:");
			int m=sc.nextInt();
			System.out.println("Enter the no of cols for frst matrix:");
			int n=sc.nextInt();
			int arr3[][]=new int[m][n];
			System.out.println("enter the elements of frst matrix:");
			for(int i=0;i<m;i++)
			{
				for(int j=0;j<n;j++) {
					arr3[i][j]=sc.nextInt();

					
				}
			}
			System.out.println("Enter the no of rows for second matrix:");
			int m1=sc.nextInt();
			System.out.println("Enter the no of cols for second matrix:");
			int n1=sc.nextInt();
			int arr4[][]=new int[m1][n1];
			System.out.println("enter the elements of second matrix:");
			for(int i=0;i<m1;i++)
			{
				for(int j=0;j<n1;j++) {
					arr4[i][j]=sc.nextInt();

					
				}
			}
			int mul[][]=new int[m][n1];
			if(n==m1)
			{
				for(int i=0;i<m;i++)
				{
					for(int j=0;j<n1;j++) 
					{
						for(int k=0;k<n;k++)
						{
							mul[i][j]=mul[i][j]+(arr3[i][k]*arr4[k][j]);
						}
						
						
					}
				}
			}
			System.out.println("Product:");
			for(int i=0;i<m;i++)
			{
				for(int j=0;j<n1;j++) {
					System.out.print(mul[i][j]+"\t");

					
				}
				System.out.print("\n");
			}
		}
}