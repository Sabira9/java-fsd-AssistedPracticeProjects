package inner;
abstract class AnonyInnerClass {
	   public abstract void display();
	}

public class Anony {

	public static void main(String[] args) {
		AnonyInnerClass i = new AnonyInnerClass()
		{

	         public void display() {
	            System.out.println("Anonymous Inner Class");
	         }
	      };
	      i.display();
	   }
}

