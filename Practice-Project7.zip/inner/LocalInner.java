package inner;

public class LocalInner {
	String name="sabi";
	void display() {
		class Inner
		{
			void msg() {
				System.out.println("Hello "+ name);
			}
		}
	
	Inner i=new Inner();
	i.msg();
	}
	public static void main(String[] args) {
		LocalInner obj=new LocalInner();
		obj.display();
	}

}
