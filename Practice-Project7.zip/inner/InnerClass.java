package inner;
class Class1
{
	String var="Hello";
	class Inner
	{
		void display()
		{
			System.out.println(var+" Student");
		}
		
	}
}

public class InnerClass {

	public static void main(String[] args) {
		Class1 c=new Class1();
		Class1.Inner i=c.new Inner();
		i.display();

	}

}
