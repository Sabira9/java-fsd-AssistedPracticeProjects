package Accessspecifier;
class ProtectedaccessSpeci{
	protected void display()
	{
		System.out.println("It is Protected specifier");
	}
}
public class Protectedaccess extends ProtectedaccessSpeci 
{ 
	public static void main(String[] args)
	{
		ProtectedaccessSpeci d=new ProtectedaccessSpeci();
		d.display();
	}

}
