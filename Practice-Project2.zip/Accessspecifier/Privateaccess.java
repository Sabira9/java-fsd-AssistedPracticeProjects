package Accessspecifier;
class PrivateaccessSpeci{
	private void display()
	{
		System.out.println("It is Private specifier");
	}
}
public class Privateaccess { 
	public static void main(String[] args) {
		PrivateaccessSpeci d=new PrivateaccessSpeci();
		//d.display();The method display() from the type PrivateaccessSpeci is not visible

	}

}
