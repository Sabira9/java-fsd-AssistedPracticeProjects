package Accessspecifier;
class PublicaccessSpeci{
	public void display()
	{
		System.out.println("It is Public specifier");
	}
}
public class Publicaccess { 
	public static void main(String[] args) {
		PublicaccessSpeci d=new PublicaccessSpeci();
		d.display();
	}

}
