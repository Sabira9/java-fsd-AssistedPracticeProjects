package Accessspecifier;
class DefaultaccessSpeci{
	void display()
	{
		System.out.println("It is Default specifier");
	}
}
public class Defaultaccess {
	public static void main(String[] args) {
		DefaultaccessSpeci d=new DefaultaccessSpeci();
		d.display();
	}

}
