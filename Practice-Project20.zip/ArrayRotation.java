package arrayprac;

public class ArrayRotation {
	public static void main(String args[])

	{
	int a[]={34,6,24,8,1};
	System.out.println("Original array:");
	for(int i=0;i<a.length;i++)
	{
     System.out.print(a[i]+"\t");
     }
	int n=1;
	while(n<=5)
	{
		 int i, last;      
         last = a[a.length-1];    
         
         for(i = a.length-1; i > 0; i--)
         {       
             a[i] = a[i-1];    
         }    
          
         a[0] = last;  
	n+=1;
	}
	System.out.println("\n");
	System.out.println("Array after rotation by 5 steps:");
	for(int i=0;i<a.length;i++)
	{
     System.out.print(a[i]+"\t");
     }
}}
