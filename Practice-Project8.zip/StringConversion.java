package stringcon;

public class StringConversion {
	public static void main(String[] args) {
		String s=new String("hello");
		System.out.println(s);
		System.out.println("\n");
		System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
        StringBuffer sbr = new StringBuffer(s); 
        sbr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbr); 
        StringBuilder sbl = new StringBuilder(s); 
        sbl.append(" world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);   
	}
	
}
	
