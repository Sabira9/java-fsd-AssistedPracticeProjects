package exception;

public class FinallyEx {

	public static void main(String[] args) {
		int a=45,b=0,rem=0;
        try
        {
            rem = a / b;
        }
        catch(Exception Ex)
        {
            System.out.print("\n\tError : " + Ex.getMessage());
        }
        finally
        {
        	
            System.out.print("\n\tThe result is : " + rem);
            System.out.println("\n\tEnd of the program");
        }

	}

}
