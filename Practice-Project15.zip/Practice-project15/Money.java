package exception;
class LowMoney extends Exception
{
	LowMoney(String str)
	{
		super(str);
	}
}
class Debit
{
	public void bal(int balance ,int amount) throws LowMoney
	{
		if(balance>20000)
			System.out.println("balance="+(balance-amount));
		else
			throw new LowMoney("low money-unable to debit");
	}
	
}

public class Money {

	public static void main(String[] args) throws LowMoney
	{
		Debit d=new Debit();
		d.bal(10000,20000);
		
	}

}
