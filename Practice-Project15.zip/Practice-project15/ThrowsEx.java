package exception;
public class ThrowsEx
{
    void Division() throws Exception
    {
        int a=50,b=0,rem;
         rem= a / b;
        System.out.print("\n\tThe result is : " + rem);
    }

	public static void main(String[] args)
	{
		ThrowsEx T = new ThrowsEx();
        try
       {
           T.Division();
       }
       catch(Exception Ex)
       {
           System.out.print("\n\tError : " + Ex.getMessage());
       }
       System.out.print("\n\tEnd of program.");
   }
}



