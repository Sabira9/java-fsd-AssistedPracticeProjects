package exception;

public class ThrowEx {

	public static void main(String[] args) {
		int a=50,b=0,rem;

        try
        {
            if(b==0)        
                throw(new ArithmeticException("Division by zero is not possible."));
            else
            {
                rem = a / b;
                System.out.print("\n\tThe result is : " + rem);
            }
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\n\tError : " + Ex.getMessage());
        }

        System.out.print("\n\tEnd of program.");
    }



	}


