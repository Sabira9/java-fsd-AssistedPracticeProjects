package threadprac;
class ThreadRunn  implements Runnable
{
	public void run()
	{
		runOdd();
		
	}
      public void runOdd()
	{
		for(int i=1;i<10;i+=2)
		{
			System.out.println(i);
		}
	}
      
}

public class ThreadInterface  {

	public static void main(String[] args) {
		ThreadRunn th=new ThreadRunn(); 
		Thread th1=new Thread(th); 
		th1.start();
		
	}

}
