package threadprac;
class ThreadPractice extends Thread
{
	public void run()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println(i);
		}
	}
}
public class ThreadPrac {

	public static void main(String[] args) {
		ThreadPractice tp=new ThreadPractice();
		tp.start();
				

	}

}
