package threadprac;

class ThreadRunnable1  implements Runnable
{
	public void run()
	{
		try {
			runOdd();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		try {
			runEven();
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
	}
      synchronized public void runOdd() throws InterruptedException
	{
		for(int i=1;i<10;i+=2)
		{
			System.out.println(i);
			Thread.sleep(2000);
		}
	}
      synchronized public void runEven() throws InterruptedException
     	{
     		for(int i=2;i<10;i+=2)
     		{
     			System.out.println(i);
     			wait(2000);
     		}
     	}
}

public class Threadwait {

	public static void main(String[] args) throws InterruptedException {
		ThreadRunnable1 th=new ThreadRunnable1(); 
		Thread th1=new Thread(th); 
		Thread th2=new Thread(th);
		th1.start();
		th2.start();
		
	}

}
