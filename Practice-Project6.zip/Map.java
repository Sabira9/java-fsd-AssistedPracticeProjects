package mappractice;
import java.util.*;
import java.util.Map.Entry;

public class Map {

	public static void main(String[] args) {
		HashMap <Integer,String> hmap=new HashMap <Integer,String>();
		hmap.put(1,"sab");
		hmap.put(2,"fathy");
		hmap.put(3,"safa");
		System.out.println("HashMap\n");
		for(Entry<Integer, String> m:hmap.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }

		Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	      
	      ht.put(4,"apple");  
	      ht.put(5,"Orange");  
	      ht.put(6,"Jackfruit");  

	      System.out.println("\nHashTable\n ");  
	      for(Entry<Integer,String> n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
         TreeMap <Integer,String> tm=new TreeMap<Integer,String>();  
	      
	      tm.put(7,"red");  
	      tm.put(8,"pink");  
	      tm.put(9,"blue");  
	     
	      System.out.println("\nTreeMap\n ");  
	      for(Entry<Integer,String> n:tm.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      

	}

}
