package collection;
import java.util.*;

public class Collect {
	public static void main(String[] args) {
		
	ArrayList <String> arr=new ArrayList <String>();
	arr.add("sab");
	arr.add("fathy");
	arr.add("safa");
	arr.add("afsu");
	System.out.println("Array List");
	System.out.println(arr);
	Vector <Integer> vec=new Vector <Integer>();
	vec.addElement(1);
	vec.addElement(2);
	vec.addElement(3);
	vec.addElement(4);
	System.out.println("\n");
	System.out.println("Vector");
	System.out.println(vec);
	HashSet <Integer> hashset=new HashSet <Integer>();
	hashset.add(10);
	hashset.add(11);
	hashset.add(12);
	hashset.add(13);
	System.out.println("\n");
	System.out.println("HashSet");
	System.out.println(hashset);
	LinkedList <String> fruits=new LinkedList <String>();
	System.out.println("\n");
	System.out.println("LinkedList");
	fruits.add("orange");
	fruits.add("apple");
	fruits.add("grapes");
	fruits.add("mango");
	Iterator<String> itr=fruits.iterator();  
    while(itr.hasNext())
    {  
     System.out.println(itr.next());  
     }
    LinkedHashSet <Integer> num=new LinkedHashSet <Integer>();
	System.out.println("\n");
	System.out.println("LinkedHashSet");
	num.add(20);
	num.add(21);
	num.add(22);
	num.add(23);
	System.out.println(num);
    }}
