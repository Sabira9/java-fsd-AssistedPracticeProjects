package pillersofoop;


	class CallMain implements calc3
	{

		@Override
		public void sum(int a,int b) {
			System.out.println(a+b);
			
		}

		@Override
		public void diff(int a,int b) {
			System.out.println(a-b);
			
		}

		@Override
		public void div(int a,int b) {
			System.out.println(a/b);
		}
		
	}

	public class AbstractInterface {

		public static void main(String[] args) {
			
	            CallMain c=new CallMain();
	            c.sum(2,5);

		}

	}



