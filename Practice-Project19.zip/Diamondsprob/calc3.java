package pillersofoop;

interface calc1
{
	public abstract void sum(int a,int b);
	public abstract void diff(int a,int b);
}

interface calc2 {

public abstract void mul(int a,int b);
}
interface calc3 extends calc1
{
	
	public abstract void div(int a,int b);
	}
