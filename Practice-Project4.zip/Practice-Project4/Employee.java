package methodImplement;

public class Employee {
	int empid;
	String name,email,phone;
	Double salary;
	//Default constructor
	Employee()
	{
		double bonus=5000.00;
		System.out.println("Employee details");
		System.out.println("Bonus="+bonus);
	}
	//Parameterized Constructor
	Employee(int empid,String name,String phone,String email,Double salary)
	{
		this.empid=empid;
		this.name=name;
		this.phone=phone;
		this.email=email;
		this.salary=salary;
	}
    void display()
    {
    	System.out.println("EMPID:"+this.empid);
    	System.out.println("NAME:"+this.name);
    	System.out.println("PHONE:"+this.phone);
    	System.out.println("MAIL:"+this.email);
    	System.out.println("SALARY:"+this.salary);
    }
}
