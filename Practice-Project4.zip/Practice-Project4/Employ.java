package methodImplement;

public class Employ {

	public static void main(String[] args) {
		Employee emp=new Employee();
		Employee emp1=new Employee(123,"sab","2503200","sab@gmail.com",40000.00);
		emp1.display();
		
	}

}
