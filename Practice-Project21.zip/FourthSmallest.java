package arrayprac;

import java.util.Arrays;

public class FourthSmallest {

	public static void main(String[] args) {
		int a[]= {34,6,24,8,1,89,5,35,15,27};
		Arrays.sort(a);
		for(int a1:a)
		{
			System.out.print(a1+"\t");
		}
		System.out.println("\n");
		System.out.println("Smallest fourth element:"+a[3]);
	}

}
