package exception;

public class ExceptionHandlers {

	public static void main(String[] args) {
		try
		{
			int num[]= {1,2,3,4};
			System.out.println(num[10]);
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println("Exception handling example");
	}

}
