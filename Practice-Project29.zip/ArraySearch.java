package arrayprac;

import java.util.Scanner;

public class ArraySearch {

	public static void main(String[] args) {
		int a[]= {3,8,5,15,46,2};
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the element to be searched:");
		int ele=sc.nextInt();
		int flag=0;
		int i=0;
		for(i=0;i<a.length;i++)
		{
			if(ele==a[i])
			{
				flag=1;
				break;
			}
			else 
			{
				flag=0;
			}
		
		}
 if(flag==1)
{
	System.out.println("element found in index:" +i);
}
else
{
	System.out.println("not found");
}
	}

}
