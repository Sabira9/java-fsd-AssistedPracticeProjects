package pillersofoop;

	class Bike {

		int speed=300;
		void display()
		{
			System.out.println("Base speed of bikes");
			System.out.println("speed="+speed);
		}
	}
	class R15 extends Bike
	{
		int speed=200;
		void speedofr15()
		{
			System.out.println("speed of r15:"+(super.speed+speed));
		}
		
	}
	class Yamaha extends Bike
	{
		int speed=300;
		void speedofyam()
		{
			System.out.println("speed of yamaha:"+(super.speed+speed));
		}
	}
	class R15prop extends  R15
	{
		String mileage="40 km/l";
		void R15mil()
		{
			System.out.println("Mileage of R15="+mileage);
		}
		
	}
	public class Inheri
	{
		public static void main(String[] args) {
			Yamaha r=new Yamaha();
			R15prop r1=new R15prop();
			r1.display();
			r1.speedofr15();
			r1.R15mil();
			r.speedofyam();			

	}
	}

