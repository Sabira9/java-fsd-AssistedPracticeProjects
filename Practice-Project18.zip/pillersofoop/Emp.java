package pillersofoop;

public class Emp {
	private int id;
	private String name;
	private double sal;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public double newsal(int bonus)
	{
		 return this.sal+bonus;
	}
	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + ", sal=" + sal + " , New Salary=" +newsal(1000)+"]";
	}
	
	
	

}
