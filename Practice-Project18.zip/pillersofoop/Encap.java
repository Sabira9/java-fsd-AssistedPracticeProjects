package pillersofoop;

public class Encap {

	public static void main(String[] args) {
		Encap1 en=new Encap1();
		en.setId(1);
		en.setName("sab");
		System.out.println(en);
		
	}

}
