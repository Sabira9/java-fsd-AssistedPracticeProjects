package pillersofoop;

public class Employee {

	public static void main(String[] args) {
		Emp em=new Emp();
		Emp em1=new Emp();
		Emp em2=new Emp();
		em.setId(1);
		em1.setId(2);
		em2.setId(3);
		em.setName("sab");
		em1.setName("safa");
		em2.setName("fathy");
		em.setSal(10000.00);
		em1.setSal(20000.00);
		em2.setSal(30000.00);
		System.out.println(em);
		System.out.println(em1);
		System.out.println(em2);
		
	}

}
