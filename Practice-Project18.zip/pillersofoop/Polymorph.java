package pillersofoop;


class Overload {
	
		public void args()
		{
			System.out.println("no arg");
		}
		public void args(int a,int b)
		{
			System.out.println(a+b);
		}
		public void args(double a,int b)
		{
			System.out.println(a*b);
		}
	}
	public class Polymorph {

		public static void main(String[] args) {
			Overload d=new Overload();
			d.args();
			d.args(5.0, 1);
		}

	}


