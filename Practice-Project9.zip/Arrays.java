package arrayimp;

public class Arrays {

	public static void main(String[] args) {
		int arr[]= {1,2,3,4,5};
		int[][] b= {{1,2,3},{10,11,12}};
		System.out.println("Elements in one-dimensional array are=");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		System.out.println("lenth of the second row="+b[0].length);
		
		}
		
	}

