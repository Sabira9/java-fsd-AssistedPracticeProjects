package arrayprac;

import java.util.Scanner;

public class QueueOpera {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the size:");
		int size=sc.nextInt();
		int Queue[]=new int[size];
		int rear=-1,front=-1;
		while(true)
		{
			System.out.println("Queue operations:");
			System.out.println("enter your choice: 1.insertion  2.deletion 3.display 4.exit");
			int ch=sc.nextInt();
			switch(ch)
			{
			case 1:if(rear==size-1)
			{
				System.out.println("overflow-no more insertions");
			}
			else
			{
				System.out.println("enter the element to be inserted:");
				int ele=sc.nextInt();
				rear++;
				Queue[rear]=ele;
				front=0;
			}
			break;
			case 2:if((front==-1&&rear==-1)||(front>rear))
			{
				System.out.println("underflow-no elements are found");
			}
			else
			{
				front=front+1;
			}
			break;
			case 3:if((front==-1&&rear==-1)||(front>rear))
			{
				System.out.println("no elements to display");
			}
			else
			{
				for(int i=front;i<=rear;i++)
				{
					System.out.println(Queue[i]);
				}
			}
			break;
			case  4:System.exit(0);
			break;
			default:System.out.println("invalid choice");
			break;
			}
		}
	}

	}

